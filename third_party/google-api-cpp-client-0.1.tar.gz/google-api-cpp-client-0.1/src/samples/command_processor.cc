/*
 * \copyright Copyright 2013 Google Inc. All Rights Reserved.
 * \license @{
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @}
 */

// Author: ewiseblatt@google.com (Eric Wiseblatt)

#include <algorithm>
using std::copy;
using std::max;
using std::min;
using std::reverse;
using std::swap;
#include <iostream>
using std::cout;
using std::endl;
using std::ostream;  // NOLINT
#include <string>
using std::string;
#include <map>
using std::map;
#include <vector>
using std::vector;

#include "googleapis/client/transport/http_response.h"
#include "samples/command_processor.h"
#include <glog/logging.h>
#include "googleapis/strings/ascii_ctype.h"
#include "googleapis/strings/strcat.h"
#include "googleapis/strings/stringpiece.h"
#include "googleapis/strings/strip.h"

namespace googleapis {

using std::cin;
using std::cerr;
using std::cout;
using client::HttpResponse;

namespace sample {

CommandProcessor::CommandProcessor()
    : prompt_("> "), log_success_bodies_(false) {
}

CommandProcessor::~CommandProcessor() {
  for (CommandEntryMap::const_iterator it = commands_.begin();
       it != commands_.end();
       ++it) {
    delete it->second;
  }
}

void CommandProcessor::InitCommands() {
  AddBuiltinCommands();
}

void CommandProcessor::AddBuiltinCommands() {
  AddCommand("quit",
     new CommandEntry(
         "", "Quit the program.",
         NewPermanentCallback(this, &CommandProcessor::QuitHandler)));
  AddCommand("help",
     new CommandEntry(
         "", "Show help.",
         NewPermanentCallback(this, &CommandProcessor::HelpHandler)));
  AddCommand("quiet",
     new CommandEntry(
         "", "Dont show successful response bodies.",
         NewPermanentCallback(this, &CommandProcessor::VerboseHandler, 0)));
  AddCommand("verbose",
     new CommandEntry(
         "", "Show successful response bodies.",
         NewPermanentCallback(this, &CommandProcessor::VerboseHandler, 1)));
}

void CommandProcessor::AddCommand(StringPiece name, CommandEntry* details) {
  commands_.insert(make_pair(name, details));
}

bool CommandProcessor::CheckAndLogResponse(HttpResponse* response) {
  util::Status transport_status = response->transport_status();
  if (!transport_status.ok()) {
    cerr << "ERROR: " << transport_status.error_message() << endl;
    return false;
  } else if (!response->ok()) {
    string body;
    util::Status status = response->GetBodyString(&body);
    if (!status.ok()) {
      StrAppend(&body, "ERROR reading HTTP response body: ",
                status.error_message());
    }
    cerr << "ERROR(" << response->http_code() << "): "
         << body << endl;
    return false;
  } else {
    cout << "OK(" << response->http_code() << ")" << endl;
    if (log_success_bodies_) {
      string body;
      util::Status status = response->GetBodyString(&body);
      if (!status.ok()) {
        StrAppend(&body, "ERROR reading HTTP response body: ",
                  status.error_message());
      }
      cout << "----------  [begin response body]  ----------" << endl;
      cout << body << endl;
      cout << "-----------  [end response body]  -----------" << endl;
    }
    return true;
  }
}

void CommandProcessor::VerboseHandler(
    int level, const string&, const vector<string>&) {
  if (level == 0) {
    cout << "Being quiet." << endl;
    log_success_bodies_ = false;
  } else {
    cout << "Being verbose." << endl;
    log_success_bodies_ = true;
  }
}

void CommandProcessor::QuitHandler(const string&, const vector<string>&) {
  VLOG(1) << "Got QUIT";
  done_ = true;
}

void CommandProcessor::HelpHandler(const string&, const vector<string>&) {
  vector<pair<StringPiece, const CommandEntry*> > all;
  for (CommandEntryMap::const_iterator it = commands_.begin();
       it != commands_.end();
       ++it) {
    all.push_back(*it);
  }

  std::sort(all.begin(), all.end(), &CommandEntry::CompareEntry);

  string help = "Commands:\n";
  for (vector<pair<StringPiece, const CommandEntry*> >::const_iterator it=
           all.begin();
       it != all.end();
       ++it) {
    StrAppend(&help, it->first);
    if (!it->second->args.empty()) {
      StrAppend(&help, " ", it->second->args);
    }
    StrAppend(&help, "\n   ", it->second->help, "\n");
  }
  cout << help << endl;
}

void CommandProcessor::RunShell() {
  if (!commands_.size()) {
    // Not called already, such as in a previous invocation to RunShell.
    InitCommands();
  }
  done_ = false;
  while (!done_) {
    cout << endl << prompt_;
    string input;
    std::getline(cin, input);

    vector<string> args;
    SplitArgs(input, &args);
    if (args.size() == 0) continue;

    string cmd = args[0];
    if (commands_.find(cmd) != commands_.end()) {
      args.erase(args.begin());  // remove command
      commands_[cmd]->runner->Run(cmd, args);
    } else {
      cerr << "Error: Unknown command '" << cmd << "'  (try 'help')\n";
    }
  }
}

// static
bool CommandProcessor::SplitArgs(
    const StringPiece& args, vector<string>* list) {
  bool ok = true;
  string current;
  const char* end = args.data() + args.size();

  for (const char* pc = args.data(); pc < end; ++pc) {
    if (ascii_isspace(*pc)) {
      if (current.empty()) continue;  // skip spaces between tokens
      list->push_back(current);
      current.clear();
      continue;
    } else if (*pc == '"') {
      // end current word and start a new one.
      if (!current.empty()) {
        list->push_back(current);
        current.clear();
      }
      // keep the contents inside double quotes but respect escapes.
      // If there was no close quote, treat it a bad parse.
      for (++pc; pc < end && *pc != '"'; ++pc) {
        if (*pc == '\\') {
          ++pc;
          if (pc == end) {
            ok = false;
            continue;
          }
        }
        current.push_back(*pc);
      }
      list->push_back(current);
      current.clear();
      ok = pc < end;
      continue;
    }
    if (*pc == '\\') {
      ++pc;
      if (pc == end) {
        ok = false;
        continue;
      }
    }
    current.push_back(*pc);
  }
  if (!current.empty()) {
    list->push_back(current);
  }
  return ok;
}

}  // namespace sample

} // namespace googleapis